

$(document).ready(function() { 
    /* Με το που φορτώσει το αρχείο, κοιτάμε αν ο χρήστης υπάρχει στο localstorage,
     * δηλαδή ο χρήστης ξέχασε να κάνει logout οπότε είναι ακόμα συνδεμένος ακόμη και αν έχει κλείσει την σελίδα του browser
     */
    var UserLocalStore = JSON.parse(localStorage.getItem('user')); // μετατροπή του string αποτελέσματος της getItem σε object 

    /* Αν έχουμε logged-in χρήστη, όταν ο χρήστης κάνει refresh, αυτή η function παίρνοντας ως παράμετρο τον user,
     * αναλαμβάνει να ελέγξει αν ο χρήστης είναι στο πρώτο επίπεδο ή έχει προχωρήσει παραπάνω 
     * ώστε να δείξει το αντίστοιχο Start, αν ξεκινάει το level1, ή Continue, αν συνεχίσει το test
     * απο το level 2 και μέτα. Αφου το ελέγξει, εμφανίζει το κουμπί 'play again' στην περίπτωση > level1,
     * κάνει remove τις φόρμες register & login από την html και εμφανίζει στην θέση τους το Welcome με όνομα χρήστη, το κουμπί logout
     * και το βασικό μας div με id=quiz (όπου σε αυτό θα προσθέτουμε(append) ή θα αφαιρούμε(remove) πράγματα) με μέσα του το button "Start ή Continue Quiz". 
     */          
    function storageIsSet(user) {
        var buttonText;
        if (user.level1.passed === false) {
            buttonText = 'Start';
        } else {
            buttonText = 'Continue';
            $('.topnav .main-centered').append('<a id=\"play-again\" href=\"#playAgain\">Play again</a>')
        }

        $('#register, #log-in').remove();
        $('.content' ).append(
            '<div id="quiz-container">' +
                '<p style=\"text-align: right;\">Welcome ' + user.firstName + ' ' + user.lastName + ' | <span id="log-out">log out</span></p>' +
                '<div id="quiz"><div align=\"center\"><button id="quiz-start">' + buttonText + ' Quiz!</button></div></div>' + 
            '</div>'
        );
    }



    // Αν ο χρήστης υπάρχει, φώναξε την πάνω συνάρτηση με παράμετρο τον χρήστη 
    if (UserLocalStore) {
        storageIsSet(UserLocalStore);
    }

    /* Logout click event listener. Αυτό το κομμάτι κώδικα περιμένει να "ακούσει" ένα event (event listener)
     * τύπου "click" στο element με id=log-out (το οποίο κατασκευάζεται στην storageIsSet function). Οταν πατηθεί το logout, θα αφαιρεθεί ο αποθηκευμένος
     * user απο το localstorage του browser και θα ξανακάνει reload το site. Έτσι στο reload o κώδικας θα δει ότι
     * το localstorage είναι άδειο, άρα δεν έχουμε συνδεμένο χρήστη και θα δείξει την αρχική σελίδα με τις φόρμες
     * register & login.
     */
    $(document).on('click', '#log-out',  function(e) { // on = event listener στο click του id=logout
        localStorage.removeItem("user"); 
        location.reload(); //συνάρτηση που ξαναφορτώνει το document από την αρχή. Ίδια λειτουργία με την location.replace(newUrl -> relative ('/'))
    });



    /* Play again click event listener. Αυτό το κομμάτι κώδικα περιμένει να "ακούσει" ένα event (event listener)
     * τύπου "click" στο element με id=play-again (storageIsSet function). Όταν πατηθεί το Play again, θα εμφανίσει ένα 
     * confirm alert που θα τον προειδοποιεί με ένα text message. Αν πατήσει οκ, τότε θα διαβάσουμε τον user από το 
     * localstorage ώστε να βρούμε το email του και θα τον αναζητήσουμε στην βαση του firebase μας βάση το email. Όταν βρούμε 
     * ότι ο χρήστης υπάρχει και έχει id, βάση του id θα κάνουμε update την βάση, μηδενίζοντας τα scores και κάνοντας false τα passed 
     * πεδία σε όλα τα levels. Αντίστοιχα θα ενημερώσουμε και τον user στο localstorage μας.
     */
    $(document).on('click', '#play-again',  function(e) {
        e.preventDefault();
        var message = "Are you sure that you want to play again the quiz? if your press OK you lose all your saved scores from the levels that you have passed."
        if(window.confirm(message)) {           
            var localUser = JSON.parse(localStorage.getItem("user"));
            db.collection("users").where("email", "==", localUser.email)
                .get()
                .then(function(querySnapshot) {                        
                        db.collection("users")
                            .doc(querySnapshot.docs[0].id)
                            .update({
                                "level1.passed": false, 
                                "level1.score": 0, 
                                "level2.passed": false, 
                                "level2.score": 0, 
                                "level3.passed": false, 
                                "level3.score": 0,
                                "level4.passed": false, 
                                "level4.score": 0,
                                "level": 1})
                            .then(function() {     
                                localUser.level1.passed = false;
                                localUser.level1.score = 0;  
                                localUser.level2.passed = false;
                                localUser.level2.score = 0;  
                                localUser.level3.passed = false;
                                localUser.level3.score = 0;  
                                localUser.level4.passed = false;
                                localUser.level4.score = 0;                                    
                                localStorage.setItem('user', JSON.stringify(localUser))                               
                                location.replace('/'); //συνάρτηση που ξαναφορτώνει το document από την αρχή. Ίδια λειτουργία με την location.reload())
                            })
                            .catch(function(error) {
                                // Μήνυμα σφάλματος φόρτωσης του document
                                console.error("Error updating document: ", error);
                            });;

                })
        };        
    });
        

    /*------------------------------ REGISTER FORM FUNCTIONALITY------------------------------*/

    /* Real time check: First name. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=first_name
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=first_name (after), εμφάνισε μήνυμα λάθους.
     */
    $('#first_name').on('input', function() { 
        var firstName = $('#first_name').val();
        $(".first-error").remove(); 
        if ($('#first_name').val().length < 1) {
            $('#first_name').after('<span class="error first-error">This field is required</span>'); //class error = κόκκινο χρώμα, class first-error = το μήνυμα του πεδίου -> This field is required.
        }																							 //after  = πηγαίνει κάτω από το πεδίο στο οποίο αναφερόμαστε.
    });


    /* Real time check: Last name. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=last_name
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=last_name (after), εμφάνισε μήνυμα λάθους.
     */
    $('#last_name').on('input', function() {
        var lastName = $('#last_name').val();
        $(".last-error").remove(); 
        if (lastName.length < 1) {
            $('#last_name').after('<span class="error last-error">This field is required</span>');
        }
    });


    /* Real time check: Email. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=email
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=last_name (after), εμφάνισε μήνυμα λάθους. Αλλιώς, έλεγξε μέσω της 
     * javascript function test αν η μεταβλητή τηρεί την μορφή ενός email. ("var regEx -> regular expression")
     */
    $('#email').on('input', function() {
        var email = $('#email').val();

        $(".email-error").remove();         

        if ($('#email').val().length < 1) {
            $('#email').after('<span class="error email-error">This field is required</span>');
        } else {
            var regEx = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
            var validEmail = regEx.test(email);            
            if (!validEmail) {
                $('#email').after('<span class="error email-error">Enter a valid email</span>'); //
            }
        }
    });


    /* Real time check: Password. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=password
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=password (after), εμφάνισε μήνυμα λάθους.
     */
    $('#password').on('input', function(event) {
        var password = $('#password').val();  
        $(".password-error").remove(); 
        if (password.length < 1 || password.length !== 4 || isNaN(Number(password))) {            
            $('#password').after('<span class="error password-error">This field is required</span>');
        }
    });


    /* Real time check: Mobile phone. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=tel
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=tel (after), εμφάνισε μήνυμα λάθους. Αλλιώς, έλεγξε μέσω της 
     * javascript function test αν η μεταβλητή τηρεί την μορφή ενός κινητού τηλεφώνου.
     */
     $('#tel').on('input', function() {
        var tel = $('#tel').val();    
        $(".tel-error").remove(); 
        if (tel.length < 1) {
            $('#tel').after('<span class="error tel-error">This field is required</span>');
        } else if (tel.length < 10 || tel.length > 10) {
            $('#tel').after('<span class="error tel-error">Mobile phone must be 10 characters long numbers</span>');
        } else {
            var regEx = /^[6]{1}[9]{1}[0-9]{8}$/;
            var validTel = regEx.test(tel);
            if (!validTel) {
                $('#tel').after('<span class="error tel-error">Enter a valid mobile phone. e.g 69xxxxxxx </span>');
            }
        }
    });


    /* Real time check: School class. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=schoolClass
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=schoolClass (after), εμφάνισε μήνυμα λάθους.
     */
    $('#schoolClass').on('input', function() {
        var schoolClass = $('#schoolClass').val();
        $(".school-class-error").remove(); 
        if (schoolClass.length < 1) {
            $('#schoolClass').after('<span class="error school-class-error">This field is required</span>');
        }
    });
       


    /* Οταν ο χρήστης πατήσει το κουμπί submit, μαζεύουμε σε μεταβλητές ότι είναι γραμμένο σε όλα τα πεδία και
     * ελέγχουμε ένα-ένα τα πεδία αν τηρούν τις προυποθέσεις τους. Αν κάποιο δεν τηρεί την προυπόθεση τοτέ η
     * μεταβλητή error αυξάνετε κατά ένα. Αν στο τέλος των ελέγχων το error === 0 τότε σημαίνει πως δεν έχουμε error
     * και είμαστε έτοιμοι να στείλουμε τον χρήστη στο firebase για αποθήκευση. Αν ο χρήστης αποθηκευτεί με επιτυχία,
     * τότε η συνάρτηση αφαιρεί την register form και στην θέση του εμφανίζει μήνυμα επιτυχίας.
     */
    /* http://form.guide/jquery/validation-using-jquery-examples.html -> (example 1) Εδώ βασιστήκαμε για να γίνει ο έλεγχος του submit */ 
    $('#user-data').submit(function(e) {
        e.preventDefault();
        var errors = 0;

        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        var email = $('#email').val();
        var password = $('#password').val();   
        var tel = $('#tel').val();   
        var schoolClass = $('#schoolClass').val();
        
        $(".error").remove();   
        
        if (first_name.length < 1) {
            $('#first_name').after('<span class="error">This field is required</span>');
            errors++;
        }

        if (last_name.length < 1) {
            $('#last_name').after('<span class="error">This field is required</span>');
            errors++;
        }

        if (email.length < 1) {
            $('#email').after('<span class="error">This field is required</span>');
            errors++;
        } else {
            var regEx = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
            var validEmail = regEx.test(email);
            if (!validEmail) {
                $('#email').after('<span class="error">Enter a valid email</span>');
                errors++;
            }
        }

        if (password.length < 4 || password.length > 4 || isNaN(Number(password))) {
            $('#password').after('<span class="error">Password must be 4 characters long numbers</span>');
            errors++;
        }

        if (tel.length < 1) {
            $('#tel').after('<span class="error">This field is required</span>');
            errors++;
        } else if (tel.length < 10 || tel.length > 10) {
            $('#tel').after('<span class="error">Mobile phone must be 10 characters long numbers</span>');
            errors++;
        } else {
            var regEx = /^[6]{1}[9]{1}[0-9]{8}$/;
            var validTel = regEx.test(tel);
            if (!validTel) {
                $('#tel').after('<span class="error">Enter a valid mobile phone. e.g 69xxxxxxx </span>');
                errors++;
            }
        }

        if (schoolClass.length < 1) {
            $('#schoolClass').after('<span class="error">This field is required</span>');
            errors++;
        }


        if (errors === 0) { // αν όλα είναι σωστά, ενημερώνω τη βάση δεδομένων 
            db.collection('users').add({
                firstName: first_name,
                lastName: last_name,                
                email: email,
                password: password,
                mobilePhone: tel,
                schoolClass: schoolClass,
                level: 1,
                level1 : { 
                    passed: false,
                    score: 0
                },
                level2 : {
                    passed: false,
                    score: 0
                },
                level3 : {
                    passed: false,
                    score: 0
                },
                level4: {
                    passed: false,
                    score: 0
                }                
            })
            .then(function(docRef) {
                console.log("Document successfully written!", docRef);
                $('#user-data').remove();
                $('.register' ).append('<h3 style=\"text-align: center; margin: 80px 0; line-height: 38px;\">Your register was successful! <br />login now</h3>');
            })
            .catch(function(error) {
                console.error("Error writing document: ", error);
            });;
        }

    });

    /*------------------------------ end of REGISTER FORM FUNCTIONALITY------------------------------*/



    /*------------------------------ LOGIN  FORM FUNCTIONALITY------------------------------*/

    /* Real time check: login_email. Κάθε φορά που ο χρήστης πληκτρολογεί ένα γράμμα στο input box με id=login_email
     * τρέχει η παρακάτω συνάρτηση η οποιά περνάει σε variable τα μέχρι τώρα γραμμένα γράμματα. Σε περίπτωση που
     * υπάρχει κάποιο μήνυμα error το σβήνει και ελέγχει αν το variable εκείνη την στιγμή τηρεί κάποιες προυποθέσεις.
     * Αν ο έλεγχος ισχύει, μετά το element με id=login_email (after), εμφάνισε μήνυμα λάθους. Αλλιώς τσέκαρε μέσω της 
     * javascript function test αν η μεταβλητή τηρεί την μορφή ενός email.
     */
    $('#login_email').on('input', function() {
        var email = $('#login_email').val();

        $(".login-email-error").remove();         

        var regEx = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
        var validEmail = regEx.test(email);            
        if (!validEmail) {
            $('#login_email').after('<span class="error login-email-error">Enter a valid email</span>');
        }
        
    });

    /* Οταν ο χρήστης πατήσει το κουμπί submit, μαζεύουμε σε μεταβλητές ότι είναι γραμμένο σε όλα τα πεδία και
     * τσεκάρουμε ένα-ένα τα πεδία αν τηρούν τις προυποθέσεις τους. Αν κάποιο δεν τηρεί την προυπόθεση τοτέ η
     * μεταβλητή error αυξάνετε κατά 1. Αν στο τέλος των ελέγχων το error === 0 τότε σημαίνει πως δεν έχουμε error
     * και είμαστε έτοιμοι να ζητήσουμε απο το firebase να μας φέρει τον user που έχει αυτό το email.
     */
    /* http://form.guide/jquery/validation-using-jquery-examples.html -> (example 1) Εδώ βασιστήκαμε για να γίνει ο έλεγχος του login */ 

    $('#log-in').submit(function(e) {
        e.preventDefault(); // δεν αφήνει να κάνει refresh o browser
        $("#error-login").remove();
        var errors = 0;

        var email = $('#login_email').val();
        var password = $('#login_password').val();
        
        $(".error").remove();

        if (email.length < 1) {
            $('#login_email').after('<span class="error">This field is required</span>');
            errors++;
        } 

        if (password.length < 1) {
            $('#login_password').after('<span class="error">Password must be 4 characters long numbers</span>');
            errors++;
        }

        if (errors === 0) {
            db.collection("users")            
                .where("email", "==", email)
                .where("password", "==", password.toString())
                .get()
                .then(function(doc) {
                    // Έλεγχος αν υπάρχει ο user
                    if (doc.docs[0].exists) {
                        var user = doc.docs[0].data(); // φέρνει τα δεδομένα του user από την βάση  
                        console.log(user);
                        var localUser = { // δεδομένα που περνάω στον localstorage
                            email: user.email,
                            firstName: user.firstName,
                            lastName: user.lastName,
                            level: user.level,
                            mobilePhone: user.mobilePhone,
                            schoolClass: user.schoolClass,
                            level1: user.level1,
                            level2: user.level2,
                            level3: user.level3,
                            level4: user.level4
                        };
                        localStorage.setItem('user', JSON.stringify(localUser));
                        
                        storageIsSet(localUser);
                        
                    } else {
                        // Σε περίπτωση σφάλματος  
                        $("#log-in").append('<p id="error-login">Your email or password is invalid. Please try again!</p>');
                        console.log("No such document!");
                    }
                    // Σε περίπτωση σφάλματος του request 
                }).catch(function(error) {
                    $("#log-in").append('<p id="error-login">Your email or password is invalid. Please try again!</p>');
                    console.log("Error getting document:", error);
                });
        }

    });

    /*------------------------------ end of LOGIN  FORM FUNCTIONALITY------------------------------*/


    // πίνακες με τα σωστά αποτελέσματα ανά level
    var correctAnswersLevel1 = ['a', 'c', 'b', 'd', 'c']; 
    var correctAnswersLevel2 = ['b', 'b', 'c', 'a', 'b']; 
    var correctAnswersLevel3 = ['a', 'b', 'd', 'c', 'a']; 
    var correctAnswersLevel4 = ['a', 'b', 'c', 'b', 'd']; 



    /* Όταν φωνάζουμε αυτή την συνάρτηση ουσιαστικά ζητάμε από τον κώδικα να φορτώσει μέσα στο
     * element με id=quiz όλο τον html κώδικα που έχει το αρχείο level-1.html . Μόλις φορτώσει, μέσα
     * στην callback function φορτώνουμε τον κώδικα που αφορά τις λειτουργίες του level-1.
     */
    function level1() {
        $('#quiz').load('level-1.html',  function() { // Callback function
            var result;

            /* Ελέγχουμε πόσα απο τα αποτελέσματα είναι σωστά και αν είναι από 3 και πάνω τότε ο χρήστης είναι έτοιμος να περάσει
             * στο επόμενο στάδιο και του εμφανίζουμε το κουμπί για να κάνει continue.
             */
            $("#form-level-1").submit(function(e) {
                e.preventDefault();
                $("#result").remove();
                var amountCorrect = 0;          
                for(var i = 0; i < 5; i++) { // Loop ερωτήσεων
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) { // Loop απαντήσεων
                        var radio = radios[j];
                        if (radio.value === correctAnswersLevel1[i] && radio.checked) {
                            amountCorrect++;
                        }
                    }
                }           
                var color;
                if (amountCorrect >=3) {
                    color = 'green';
                } else {
                    color = 'red';
                }

                result = (amountCorrect * 100)/5;
                $('#form-level-1').append('<p id=\"result\" style=\"color:' + color + '; margin: 10px 0; font-size: 16px;\">Result:' + result + '/100</p>'); 
                if (result > 50) {
                    $('#result').append('<br><button id=\"continue\">Continue to level 2</button>')
                }                                 
            });

            // Σβήνουμε όλες τις επιλογές που μπορεί να έχει επιλέξει ο χρήστης πριν τις κάνει submit
            $(document).on('click', "#reset",  function() {
                var counter = 0;
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) {
                        var radio = radios[j];
                        if (radio.checked) {
                            counter ++;
                            radio.checked = false;
                        }
                    }
                }
                if (counter > 0) {
                    alert("All selected answers are deleted");
                }
            })



            /* Click event listener για να προχωρήσουμε στο επόμενο level. Πριν προχωρήσουμε, φέρνουμε τον user μας απο το localstorage,
             * ψάχνουμε βάση του email του στην βάση του firebase. Μόλις βρούμε το id του, κάνουμε update το level που είμαστε. Μόλις γίνει επιτυχώς,
             * κάνουμε update και τον user στη localstorage, φωνάζουμε την αντίστοιχη function του επόμενου level και κάνουμε remove την html
             * του level που είμαστε βάση το id του main div του.
             */
            $(document).on('click', '#continue', function(e) {
                e.preventDefault();                
                var localUser = JSON.parse(localStorage.getItem("user"));
                db.collection("users").where("email", "==", localUser.email)
                    .get()
                    .then(function(querySnapshot) { // Στην περίπτωση που υπάρχει ο χρήστης στον firebase
                            db.collection("users")
                                .doc(querySnapshot.docs[0].id)
                                .update({"level1.passed": true, "level1.score": result, "level": 2})
                                .then(function() { // Αφου έγινε επιτυχές update στη βάση, ενημερώνουμε και το localstorage    
                                    localUser.level1.passed = true;
                                    localUser.level1.score = result;
                                    localUser.level = 2;
                                    localStorage.setItem('user', JSON.stringify(localUser)) //μετατροπή σε JSON για να ενημερώσω το localstorage                       
                                    level2();
                                    $('#level-1').remove();
                                })
                                .catch(function(error) {
                                    //Μήνυμα σφάλματος
                                    console.error("Error updating document: ", error);
                                });;

                    })                                    
            });
        
        });
    }



    /* Όταν φωνάζουμε αυτή την συνάρτηση ουσιαστικά ζητάμε απο τον κώδικα πρώτα να δει αν υπάρχει το κουμπί "play again" 
     * και αν δεν υπάρχει να το φορτώσει στο μενού. Μετά να φορτώσει μέσα στο element με id=quiz όλο το αρχείο level-2. 
     * Μόλις φορτώσει, μέσα στην callback function φορτώνουμε τον κώδικα που αφορά τις λειτουργίες του level-2. 
     */
    function level2() {
        var finded = $('.topnav .main-centered').find("#play-again");
        if (finded.length === 0) {
            $('.topnav .main-centered').append('<a id=\"play-again\" href=\"#playAgain\">Play again</a>');
        }

        $('#quiz').load('level-2.html',  function() {               
            var result;

             /* Ελέγχουμε πόσα από τα αποτελέσματα είναι σωστά και αν είναι από 3 και πάνω τότε ο χρήστης είναι έτοιμος να περάσει
             * στο επόμενο στάδιο και του εμφανίζουμε το κουμπί για να κάνει continue.
             */
            $("#form-level-2").submit(function(e) {
                e.preventDefault();
                $("#result").remove();
                var amountCorrect = 0;          
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) {
                        var radio = radios[j];
                        if (radio.value === correctAnswersLevel2[i] && radio.checked) {
                            amountCorrect++;
                        }
                    }
                }    
                var color;
                if (amountCorrect >=3) {
                    color = 'green';
                } else {
                    color = 'red';
                }

                result = (amountCorrect * 100)/5;
                $('#form-level-2').append('<p id=\"result\" style=\"color:' + color + '; margin: 10px 0; font-size: 16px;\">Result:' + result + '/100</p>');         
                if (result > 50) {
                    $('#result').append('<br><button id=\"continue\">Continue to level 3</button>')
                }                                                       
            });

            // Σβήνουμε όλες τις επιλογές που μπορεί να έχει επιλέξει ο χρήστης πρις τις κάνει submit
            $(document).on('click', "#reset",  function(e) {
                e.preventDefault();
                var counter = 0;
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) {
                        var radio = radios[j];
                        if (radio.checked) {
                            counter ++;
                            radio.checked = false;
                        }
                    }
                }
                if (counter > 0) {
                    alert("All selected answers are deleted");
                }
            })



            /* Click event listener για να προχωρήσουμε στο επόμενο level. Πριν προχωρήσουμε, φέρνουμε τον user μας απο το localstorage,
             * ψάχνουμε βάση του email του στην βάση του firebase. Μόλις βρούμε το id του, κάνουμε update το level που είμαστε. Μόλις γίνει επιτυχώς,
             * κανουμε update και τον user στη localstorage, φωνάζουμε την αντίστοιχη function του επόμενου level και κάνουμε remove την html
             * του level που είμαστε βάση το id του main div του.
             */
            $(document).on('click', '#continue', function(e) {
                e.preventDefault();
                var localUser = JSON.parse(localStorage.getItem("user"));
                db.collection("users").where("email", "==", localUser.email)
                    .get()
                    .then(function(querySnapshot) { // Στην περίπτωση που υπάρχει ο χρήστης στον firebase
                            db.collection("users")
                                .doc(querySnapshot.docs[0].id)
                                .update({"level2.passed": true, "level2.score": result, "level": 3})
                                .then(function() {     
                                    localUser.level2.passed = true;
                                    localUser.level2.score = result;
                                    localUser.level = 3;
                                    localStorage.setItem('user', JSON.stringify(localUser))                               
                                    level3();
                                    $('#level-2').remove();
                                })
                                .catch(function(error) {
                                    // Μήνυμα σφάλματος
                                    console.error("Error updating document: ", error);
                                });;

                    })           
            });
        
        });
    }



    /* Όταν φωνάζουμε αυτή την συνάρτηση ουσιαστικά ζητάμε απο τον κώδικα πρώτα να δει αν υπάρχει το κουμπί "play again" 
     * και αν δεν υπάρχει να το φορτώσει στο μενού. Μετά να φορτώσει μέσα στο element με id=quiz όλο το αρχείο level-3.html. 
     * Μόλις φορτώσει, μέσα στην callback function φορτωνουμε τον κώδικα που αφορά τις λειτουργίες του level-3.
     */
    function level3() {
        var finded = $('.topnav .main-centered').find("#play-again");
        if (finded.length === 0) {
            $('.topnav .main-centered').append('<a id=\"play-again\" href=\"#playAgain\">Play again</a>');
        }

        $('#quiz').load('level-3.html',  function() {                                        
            var result;

             /* Ελέγχουμε πόσα απο τα αποτελέσματα είναι σωστά και αν είναι από 3 και πάνω τότε ο χρήστης είναι έτοιμος να περάσει
             * στο επόμενο στάδιο και του εμφανίζουμε το κουμπί για να κάνει continue.
             */
            $("#form-level-3").submit(function(e) {
                e.preventDefault();
                $("#result").remove();
                var amountCorrect = 0;          
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) {
                        var radio = radios[j];
                        if (radio.value === correctAnswersLevel3[i] && radio.checked) {
                            amountCorrect++;
                        }
                    }
                }
                var color;
                if (amountCorrect >=3) {
                    color = 'green';
                } else {
                    color = 'red';
                }

                result = (amountCorrect * 100)/5;
                $('#form-level-3').append('<p id=\"result\" style=\"color:' + color + '; margin: 10px 0; font-size: 16px;\">Result:' + result + '/100</p>');  
                if (result > 50) {
                    $('#result').append('<br><button id=\"continue\">Continue to level 4</button>')
                }                                                            
            });

            // Σβήνουμε όλες τις επιλογές που μπορεί να έχει επιλέξει ο χρήστης πριν τις κάνει submit
            $(document).on('click', "#reset", function(e) {
                e.preventDefault();
                var counter = 0;
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 5; j++) {
                        var radio = radios[j];
                        if (radio.checked) {
                            counter ++;
                            radio.checked = false;
                        }
                    }
                }
                if (counter > 0) {
                    alert("All selected answers are deleted");
                }
            });



            /* Click event listener για να προχωρήσουμε στο επόμενο level. Πριν προχωρήσουμε φέρνουμε τον user μας απο το localstorage,
             * ψάχνουμε βάση του email του στην βάση του firebase. Μόλις βρούμε το id του, κάνουμε update το level που είμαστε. Μόλις γίνει επιτυχώς,
             * κανουμε update και τον user στη localstorage, φωνάζουμε την αντίστοιχη function του επόμενου level και κάνουμε remove την html
             * του level που είμαστε βάση το id του main div του.
             */
            $(document).on('click', '#continue',  function(e) {
                e.preventDefault();
                var localUser = JSON.parse(localStorage.getItem("user"));
                db.collection("users").where("email", "==", localUser.email)
                    .get()
                    .then(function(querySnapshot) { // Στην περίπτωση που υπάρχει ο χρήστης στον firebase
                            db.collection("users")
                                .doc(querySnapshot.docs[0].id)
                                .update({"level3.passed": true, "level3.score": result, "level": 3})
                                .then(function() {     
                                    localUser.level3.passed = true;
                                    localUser.level3.score = result;
                                    localUser.level = 4;
                                    localStorage.setItem('user', JSON.stringify(localUser))                               
                                    level4();
                                    $('#level-3').remove();
                                })
                                .catch(function(error) {
                                    // Μήνυμα λάθους
                                    console.error("Error updating document: ", error);
                                });;

                    })                 
            })
        
        });
    }

    /* Όταν φωνάζουμε αυτή την συνάρτηση ουσιαστικά ζητάμε απο τον κώδικα πρώτα να δει αν υπάρχει το κουμπί "play again" 
     * και αν δεν υπάρχει να το φορτώσει στο μενού. Μετά να φορτώσει μέσα στο element με id=quiz όλο το αρχείο level-4.html. 
     * Μόλις φορτώσει, μέσα στην callback function φορτώνουμε τον κώδικα που αφορά τις λειτουργίες του level-4.
     */
    function level4() {
        var finded = $('.topnav .main-centered').find("#play-again");
        if (finded.length === 0) {
            $('.topnav .main-centered').append('<a id=\"play-again\" href=\"#playAgain\">Play again</a>');
        }

        $('#quiz').load('level-4.html',  function() {
            var result; 

            /* Ελέγχουμε πόσα απο τα αποτελέσματα είναι σωστά και αν είναι από 3 και πάνω τότε ο χρήστης είναι έτοιμος να περάσει
             * στο επόμενο στάδιο και του εμφανίζουμε το κουμπί για να κάνει continue.
             */
            $("#form-level-4").submit(function(e) {
                e.preventDefault();
                $("#result").remove();
                var amountCorrect = 0;          
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 4; j++) {
                        var radio = radios[j];
                        if (radio.value === correctAnswersLevel4[i] && radio.checked) {
                            amountCorrect++;
                        }
                    }
                }  
                var color;
                if (amountCorrect >=3) {
                    color = 'green';
                } else {
                    color = 'red';
                }

                result = (amountCorrect * 100)/5;
                $('#form-level-4').append('<p id=\"result\" style=\"color:' + color + '; margin: 10px 0; font-size: 16px;\">Result:' + result + '/100</p>');          
                if (result > 50) {
                    $('#result').append('<br><button id=\"continue\">See results</button>')
                }                                                        
            });

            // Σβήνουμε όλες τις επιλογές που μπορεί να έχει επιλέξει ο χρήστης πρις τις κάνει submit
            $(document).on('click', "#reset",  function(e) {
                e.preventDefault();
                var counter = 0;
                for(var i = 0; i < 5; i++) {
                    var radios = document.getElementsByName(i + 1);
                    for(var j = 0; j < 4; j++) {
                        var radio = radios[j];
                        if (radio.checked) {
                            counter ++;
                            radio.checked = false;
                        }
                    }
                }
                if (counter > 0) {
                    alert("All selected answers are deleted");
                }
            })



            /* Click event listener για να προχωρήσουμε στο επόμενο level. Πριν προχωρήσουμε φέρνουμε τον user μας απο το localstorage,
             * ψάχνουμε βάση του email του στην βάση του firebase. Μόλις βρούμε το id του, κάνουμε update το level που είμαστε. Μόλις γίνει επιτυχώς,
             * κανουμε update και τον user στη localstorage, φωνάζουμε την αντίστοιχη function που δείχνει το τελικό αποτέλεσμα και κάνουμε remove την html
             * του level που είμαστε βάση το id του main div του.
             */
            $(document).on('click', '#continue',  function(e) {
                e.preventDefault();
                var localUser = JSON.parse(localStorage.getItem("user"));
                db.collection("users").where("email", "==", localUser.email)
                    .get()
                    .then(function(querySnapshot) { // Στην περίπτωση που υπάρχει ο χρήστης στον firebase
                            db.collection("users")
                                .doc(querySnapshot.docs[0].id)
                                .update({"level4.passed": true, "level4.score": result, "level": 4})
                                .then(function() {     
                                    localUser.level4.passed = true;
                                    localUser.level4.score = result;                                    
                                    localStorage.setItem('user', JSON.stringify(localUser))                               
                                    finalResults();
                                    $('#level-4').remove();
                                })
                                .catch(function(error) {
                                    // Μήνυμα σφάλματος 
                                    console.error("Error updating document: ", error);
                                });;

                    })                 
            })
        
        });
    }



    /* Η συνάρτηση αυτή χρησιμοποιείται για να φορτώσει την τελευταία σελίδα με το τελικό αποτέλεσμα όπου μας δείχνει το τελικό σκόρ.
     * Επίσης εμφανίζει ένα κουμπί για να στέλνει ο χρήστης τα αποτελέσματα του στους διαχειριστές του site
     */
    function finalResults() {
        var user = JSON.parse(localStorage.getItem("user"));
        var calculateResult = (user.level1.score + user.level2.score + user.level3.score + user.level4.score) / 4;

        $('#quiz').load('final-result.html',  function() {
            
            $("#final-result .main-centered").append("<h3 class=\"center\">Congratulation!!! You completed the quiz successfully</h3>" + 
                "<p class=\"center\">Your score is <span id=\"score\">" + calculateResult + "/100</span> </p>" +
                "<button type=\"button\" id=\"send_email\">Send result to admin</button>"                
            )
           
        })



        /* Οταν ο χρήστης πατήσει να στείλει μήνυμα, χρησιμοποιούμε www.smtpjs.com όπου μέσω του μηχανισμού του, στέλνουμε τo email με το αποτέλεσμα
         * στον καθηγητή. Οταν ο event listener δει ότι έχουμε click event στο id=send_email πρώτα τσεκάρει αν υπάρχει μήνυμα επιτυχούς αποστολής email. Αν υπάρχει
         * σημαίνει ότι ο χρήστης έχει πατήσει πάνω απο 1 φορά το button οπότε τον ενημερώνει με confirm μήνυμα. Αν πατήσει ΟΚ, σημαίνει ότι θέλει να ξαναστείλει το μήνυμα
         * οπότε αφαιρεί το παλιό success μήνυμα, στέλνει το email και μετά εμφανίζει ξανά το success μήνυμα με μια καθυστέρηση 2,5 sec και το success response ότι το μήνυμα στάλθηκε
         * απο το smtpjs.com. Σε περίπτωση που ο χρήστης έχει πατήσει πρώτη φορά το email, τότε το στέλνει κανονικά και στο τέλος εμφανίζει το success μήνυμα.
         */
        $(document).on('click', '#send_email', function(e) { 
            e.preventDefault();     
            var finded = $('#final-result .main-centered').find("#success-message"); 
            if (finded.length > 0) { // Σημαίνει οτι το έχει πατήσει το κουμπί παραπάνω απο 1 φορά
                var message = "You have already sent your score. Are you sure that you want to send it again?"
                if(window.confirm(message)) {  
                    $("#success-message").remove();
                    Email.send("giwrgoskol@hotmail.com",
                        "dimkots@sch.gr",
                        "English Learning App: Final success results",
                        "<h3 style=\"text-align: center; font-size: 24px; color: darkslateblue\">Congratulation!!! You completed the quiz successfully! </h3><p style=\"text-align: center; font-size: 16px;\">Your score is <span style=\"color: green; font-weight: bold;\">" + calculateResult + "/100</span></p>",
                        "smtp.elasticemail.com",
                        "giwrgoskol@hotmail.com",
                        "97742dd2-6cd6-4857-a074-f26ca130a2b5",
                        function done(message) { 
                            setTimeout(function(){ 
                                $("#final-result .main-centered").append("<div id=\"success-message\">Your email has been sent successfully</div>") 
                            }, 2500);
                            
                        });
                }
            } else { // Σημαίνει ότι το έχει πατήσει το κουμπί πρώτη φορά
                Email.send("giwrgoskol@hotmail.com",
                    "dimkots@sch.gr",
                    "English Learning App: Final success results",
                    "<h3 style=\"text-align: center; font-size: 24px; color: darkslateblue\">Congratulation!!! You completed the quiz successfully! </h3><p style=\"text-align: center; font-size: 16px;\">Your score is <span style=\"color: green; font-weight: bold;\">" + calculateResult + "/100</span></p>",
                    "smtp.elasticemail.com",
                    "giwrgoskol@hotmail.com",
                    "97742dd2-6cd6-4857-a074-f26ca130a2b5",
                    function done(message) { 
                        $("#final-result .main-centered").append("<div id=\"success-message\">Your email has been sent successfully</div>")
                    });
            }
            
        });
      
    }

        
    
    /* Click event listener για το button της πρώτης σελίδας μετά το επιτυχημένο log-in του user.
     * Φέρνουμε τον user από το localstorage και τσεκάρουμε ένα-ένα τα levels αν είναι passed. Όποιο
     * δεν είναι, φορτώνουμε την αντίστοιχη function που αφορά το level.
     */
    $(document).on('click', '#quiz-start', function() {
        var user = JSON.parse(localStorage.getItem('user'));        
        if (user.level1.passed === false) {
            level1();
        } else if (user.level2.passed === false) {
            level2();
        } else if (user.level3.passed === false) {
            level3();
        } else if (user.level4.passed === false) {
            level4();
        } else {
            finalResults();
        }
        $('#quiz-start').remove();
    });

    
   
});
